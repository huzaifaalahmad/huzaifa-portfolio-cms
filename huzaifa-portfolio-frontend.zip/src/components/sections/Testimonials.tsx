import { testimonials } from '@/data/testimonials';
import { useLanguage } from '@/context/LanguageContext';
import SectionHeader from '@/components/ui/SectionHeader';
export default function Testimonials(){const{t}=useLanguage();return <section className="section"><SectionHeader eyebrow="07 / Trust" title={{en:'How people describe working with me',ar:'كيف يصف الناس العمل معي'}} description={{en:'Clear thinking, structured execution, and polished delivery.',ar:'تفكير واضح وتنفيذ منظم وتسليم مصقول.'}}/><div className="card-grid">{testimonials.map(x=><blockquote className="quote-card" key={x.id}><p>“{t(x.text)}”</p><footer><strong>{t(x.clientName)}</strong><span>{t(x.clientRole)} — {t(x.clientCompany)}</span></footer></blockquote>)}</div></section>}
