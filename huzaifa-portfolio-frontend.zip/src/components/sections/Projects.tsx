import { Link } from 'react-router-dom';
import { projects } from '@/data/projects';
import { useLanguage } from '@/context/LanguageContext';
import SectionHeader from '@/components/ui/SectionHeader';
export default function Projects(){const{t}=useLanguage();return <section id="projects" className="section"><SectionHeader eyebrow="05 / Projects" title={{en:'Selected work built to prove capability',ar:'أعمال مختارة لإثبات القدرة'}} description={{en:'Each project is framed around problem, solution, role, and impact.',ar:'كل مشروع معروض حول المشكلة والحل والدور والأثر.'}}/><div className="project-grid">{projects.map(p=><article className="project-card" key={p.id}><span className="badge">{p.category}</span><h3>{t(p.title)}</h3><p>{t(p.shortDescription)}</p><div className="chips">{p.technologies.slice(0,4).map(x=><b key={x}>{x}</b>)}</div><Link to={`/projects/${p.slug}`} className="text-link">Case Study →</Link></article>)}</div></section>}
