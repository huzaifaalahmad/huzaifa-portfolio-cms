import { profile } from '@/data/profile';
import { stats } from '@/data/stats';
import { useLanguage } from '@/context/LanguageContext';
import SectionHeader from '@/components/ui/SectionHeader';
export default function About(){const{t}=useLanguage();return <section id="about" className="section"><SectionHeader eyebrow="01 / About" title={{en:'A practical builder between AI, software, and design',ar:'بناء عملي بين الذكاء الاصطناعي والبرمجيات والتصميم'}} description={profile.bio}/><div className="stats-grid">{stats.map(s=><div className="stat-card" key={s.id}><strong>{s.value}{s.suffix}</strong><span>{t(s.label)}</span></div>)}</div></section>}
