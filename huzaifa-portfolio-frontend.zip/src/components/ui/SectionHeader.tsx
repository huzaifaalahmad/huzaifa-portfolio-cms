import { BilingualText } from '@/types';
import { useLanguage } from '@/context/LanguageContext';
export default function SectionHeader({eyebrow,title,description}:{eyebrow:string;title:BilingualText;description:BilingualText}){const{t}=useLanguage();return <div className="section-header"><span className="eyebrow">{eyebrow}</span><h2>{t(title)}</h2><p>{t(description)}</p></div>}
