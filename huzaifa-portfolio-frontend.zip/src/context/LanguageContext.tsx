import { createContext, ReactNode, useContext, useMemo, useState } from 'react';
import { BilingualText, Lang } from '@/types';
interface Ctx { language: Lang; setLanguage: (l:Lang)=>void; t:(text:BilingualText)=>string; dir:'rtl'|'ltr'; }
const LanguageContext = createContext<Ctx | null>(null);
export function LanguageProvider({children}:{children:ReactNode}){ const [language,setLanguage]=useState<Lang>(()=>(localStorage.getItem('lang') as Lang)||'en'); const dir=language==='ar'?'rtl':'ltr'; const value=useMemo(()=>({language,setLanguage:(l:Lang)=>{localStorage.setItem('lang',l);setLanguage(l)},t:(text:BilingualText)=>text[language],dir}),[language,dir]); return <LanguageContext.Provider value={value}><div dir={dir} lang={language}>{children}</div></LanguageContext.Provider> }
export function useLanguage(){ const c=useContext(LanguageContext); if(!c) throw new Error('useLanguage must be used within LanguageProvider'); return c; }
