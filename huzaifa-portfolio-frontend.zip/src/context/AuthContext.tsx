import { createContext, ReactNode, useContext, useState } from 'react';
import { authApi } from '@/services/api/authApi';
type User={id:string;email:string;role:string;name?:string};
const AuthContext=createContext<{user:User|null;isAuthenticated:boolean;login:(email:string,password:string)=>Promise<void>;logout:()=>Promise<void>}|null>(null);
export function AuthProvider({children}:{children:ReactNode}){ const [user,setUser]=useState<User|null>(null); const isAuthenticated=Boolean(localStorage.getItem('access-token')); async function login(email:string,password:string){const res=await authApi.login(email,password); localStorage.setItem('access-token',res.data.accessToken); localStorage.setItem('refresh-token',res.data.refreshToken); setUser(res.data.user)} async function logout(){await authApi.logout().catch(()=>null);localStorage.removeItem('access-token');localStorage.removeItem('refresh-token');setUser(null)} return <AuthContext.Provider value={{user,isAuthenticated,login,logout}}>{children}</AuthContext.Provider> }
export function useAuth(){const c=useContext(AuthContext); if(!c) throw new Error('AuthProvider missing'); return c;}
