import { SocialLink } from '@/types';
export const socialLinks: SocialLink[] = [
 {id:'1',platform:'GitHub',url:'#',icon:'github',isVisible:true,order:1},{id:'2',platform:'LinkedIn',url:'#',icon:'linkedin',isVisible:true,order:2},{id:'3',platform:'Behance',url:'#',icon:'behance',isVisible:true,order:3},{id:'4',platform:'Email',url:'mailto:huzaifaalahmad23@gmail.com',icon:'mail',isVisible:true,order:4}
];
